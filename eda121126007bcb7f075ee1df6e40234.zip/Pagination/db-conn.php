<?php

// Define needed credentials. 
define("HOST", "localhost");
define("USER", 'root');
define("PASS", '');
define("DB", 'test');

// Establish Connection. 
$conn = new mysqli(HOST, USER, PASS, DB)
        or die('Error connecting to Database.');
?> 


